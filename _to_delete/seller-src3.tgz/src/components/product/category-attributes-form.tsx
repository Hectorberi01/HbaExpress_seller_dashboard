"use client";

import { useMemo } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { CategoryAttribute } from "@/types/seller";

/**
 * ═══════════════════════════════════════════════════════════════════════════════════
 * LE FORMULAIRE D'ATTRIBUTS, DESSINÉ DEPUIS LE SCHÉMA DE LA CATÉGORIE.
 *
 * `CategorySummary.AttributeSchema` existe depuis longtemps côté serveur, et son
 * commentaire dit exactement à quoi il sert : donner à l'application vendeur « de quoi
 * dessiner le formulaire (libellés, types, listes de valeurs, champs obligatoires) au
 * lieu d'un champ "attributs" libre où chacun invente ses clés ». La console ne le
 * lisait nulle part — zéro occurrence dans tout `src/`.
 *
 * CE QUE COÛTAIT CE TROU, ET IL COÛTAIT PLUS QUE DE L'ESTHÉTIQUE :
 *
 *  • L'ASSISTANT DE CRÉATION N'ENVOYAIT AUCUN ATTRIBUT. Dès que l'administration pose
 *    un attribut « obligatoire » sur une catégorie, `CategoryAttributeSchema.Validate`
 *    refuse toute création — et le refus arrive APRÈS le téléversement des photos.
 *    Impasse complète, sans un seul champ à l'écran pour satisfaire la règle.
 *
 *  • LA FICHE ÉDITAIT EN CLÉ/VALEUR LIBRES. Le serveur, lui, contrôle le type, les
 *    bornes, l'appartenance à une liste fermée, et refuse toute clé inconnue quand la
 *    catégorie ne les autorise pas. Le vendeur tapait « Bleu marine » dans une
 *    catégorie qui n'admet que rouge, bleu ou noir : refusé, sans que l'écran lui ait
 *    jamais montré la liste — que le serveur lui envoie pourtant à chaque chargement.
 *
 * ─────────────────────────────────────────────────────────────────────────────────
 * DEUX RÈGLES DE CONCEPTION, TOUTES DEUX DICTÉES PAR LE SERVEUR.
 *
 * 1. ON N'ENVOIE PAS CE QUI EST VIDE. Un attribut facultatif laissé vide ne doit pas
 *    partir comme chaîne vide : `Validate` traite le blanc comme absent pour
 *    l'obligation, mais une clé vide dans une catégorie fermée deviendrait une clé
 *    « inattendue ». Le filtrage est fait au moment de produire l'objet, pas à la
 *    saisie — sans quoi le champ se viderait sous les doigts du vendeur.
 *
 * 2. LES CLÉS SONT CELLES DU SCHÉMA, TELLES QUELLES. Le domaine canonise (`Normalize`)
 *    et accepte les variantes de casse, mais c'est un rattrapage : la console n'a
 *    aucune raison d'en avoir besoin puisqu'elle tient la clé exacte.
 *
 * LES VALEURS RESTENT DES CHAÎNES, y compris pour les nombres et les booléens. C'est
 * la forme du contrat (`IReadOnlyDictionary<string, string>`) : convertir ici, puis
 * reconvertir à l'envoi, n'ajouterait qu'un endroit où « 1,5 » et « 1.5 » divergent.
 * Le point décimal est imposé côté saisie, parce que `decimal.TryParse` est appelé en
 * `InvariantCulture` et refuse la virgule.
 * ═══════════════════════════════════════════════════════════════════════════════════
 */

/** Valeurs saisies, indexées par la clé technique du schéma. */
export type ValeursAttributs = Record<string, string>;

/**
 * Ne garde que ce qui est réellement renseigné. À appeler au moment de construire la
 * charge utile, jamais pendant la frappe.
 */
export function attributsANEnvoyer(valeurs: ValeursAttributs): Record<string, string> {
  const sortie: Record<string, string> = {};
  for (const [cle, valeur] of Object.entries(valeurs)) {
    const propre = (valeur ?? "").trim();
    if (propre.length > 0) sortie[cle] = propre;
  }
  return sortie;
}

/**
 * Les attributs obligatoires encore vides, par LIBELLÉ — c'est ce que le vendeur lit.
 * Miroir exact de la première boucle de `CategoryAttributeSchema.Validate`.
 */
export function obligatoiresManquants(
  schema: CategoryAttribute[],
  valeurs: ValeursAttributs,
): string[] {
  return schema
    .filter((a) => a.required && (valeurs[a.key] ?? "").trim().length === 0)
    .map((a) => a.label || a.key);
}

/**
 * Le message d'erreur d'UNE valeur, ou null si elle passe. Reprend `ValidateValue`
 * côté domaine — bornes comprises — pour que le refus arrive à la saisie et non après
 * l'envoi des photos. Le serveur reste l'autorité : ceci ne le remplace pas.
 */
export function problemeAttribut(def: CategoryAttribute, brut: string): string | null {
  const valeur = (brut ?? "").trim();
  if (valeur.length === 0) return null;

  const suffixe = def.unit ? ` ${def.unit}` : "";

  if (def.type === "number") {
    // Même exigence que `decimal.TryParse` en InvariantCulture : point décimal, pas
    // de virgule. Le dire ici évite un refus serveur incompréhensible.
    if (!/^-?\d+(\.\d+)?$/.test(valeur)) {
      return `« ${def.label} » doit être un nombre (point décimal, pas de virgule).`;
    }
    const n = Number(valeur);
    if (def.min != null && n < def.min) {
      return `« ${def.label} » ne peut pas être inférieur à ${def.min}${suffixe}.`;
    }
    if (def.max != null && n > def.max) {
      return `« ${def.label} » ne peut pas dépasser ${def.max}${suffixe}.`;
    }
    return null;
  }

  if (def.type === "boolean") {
    return valeur === "true" || valeur === "false"
      ? null
      : `« ${def.label} » doit valoir oui ou non.`;
  }

  if (def.type === "enum") {
    return (def.values ?? []).some((v) => v.toLowerCase() === valeur.toLowerCase())
      ? null
      : `« ${def.label} » doit être l'une des valeurs : ${(def.values ?? []).join(", ")}.`;
  }

  // Texte : Min et Max sont des LONGUEURS, pas des bornes numériques.
  if (def.min != null && valeur.length < def.min) {
    return `« ${def.label} » doit comporter au moins ${def.min} caractères.`;
  }
  const maxi = def.max ?? 500;
  return valeur.length > maxi
    ? `« ${def.label} » ne peut pas dépasser ${maxi} caractères.`
    : null;
}

/** Vrai si tout le schéma est satisfait — obligatoires remplis et valeurs valides. */
export function attributsValides(
  schema: CategoryAttribute[],
  valeurs: ValeursAttributs,
): boolean {
  if (obligatoiresManquants(schema, valeurs).length > 0) return false;
  return schema.every((def) => problemeAttribut(def, valeurs[def.key] ?? "") === null);
}

export function CategoryAttributesForm({
  schema,
  valeurs,
  onChange,
  categorieChoisie,
}: {
  /** Le schéma de la catégorie choisie. Vide = la catégorie n'impose rien. */
  schema: CategoryAttribute[];
  valeurs: ValeursAttributs;
  onChange: (valeurs: ValeursAttributs) => void;
  /** Faux tant qu'aucune catégorie n'est choisie : on ne sait pas quoi demander. */
  categorieChoisie: boolean;
}) {
  const poser = (cle: string, valeur: string) => onChange({ ...valeurs, [cle]: valeur });

  const obligatoires = useMemo(() => schema.filter((a) => a.required).length, [schema]);

  if (!categorieChoisie) {
    return (
      <p className="text-xs text-muted-foreground">
        Choisissez d&apos;abord une catégorie : c&apos;est elle qui détermine les
        caractéristiques attendues.
      </p>
    );
  }

  if (schema.length === 0) {
    return (
      <p className="text-xs text-muted-foreground">
        Cette catégorie n&apos;impose aucune caractéristique.
      </p>
    );
  }

  return (
    <div className="space-y-3">
      {obligatoires > 0 && (
        <p className="text-xs text-muted-foreground">
          {obligatoires === 1
            ? "Une caractéristique est obligatoire dans cette catégorie."
            : `${obligatoires} caractéristiques sont obligatoires dans cette catégorie.`}{" "}
          La fiche sera refusée sans elles.
        </p>
      )}

      {schema.map((def) => {
        const valeur = valeurs[def.key] ?? "";
        const probleme = problemeAttribut(def, valeur);
        const champId = `attr-${def.key}`;

        return (
          <div key={def.key} className="space-y-1.5">
            <Label htmlFor={champId}>
              {def.label || def.key}
              {def.required && <span className="ml-1 text-destructive">*</span>}
              {def.unit && <span className="ml-1 text-muted-foreground">({def.unit})</span>}
            </Label>

            {def.type === "enum" ? (
              <select
                id={champId}
                value={valeur}
                onChange={(e) => poser(def.key, e.target.value)}
                className="flex h-9 w-full rounded-md border border-input bg-background px-3 text-sm"
              >
                {/* L'entrée vide reste proposée même sur un champ obligatoire : la
                    retirer choisirait une valeur à la place du vendeur, et la
                    première de la liste passerait pour un choix délibéré. */}
                <option value="">— Choisir —</option>
                {(def.values ?? []).map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            ) : def.type === "boolean" ? (
              <select
                id={champId}
                value={valeur}
                onChange={(e) => poser(def.key, e.target.value)}
                className="flex h-9 w-full rounded-md border border-input bg-background px-3 text-sm"
              >
                {/* Trois états, et c'est volontaire : une case à cocher n'aurait pas su
                    dire « non renseigné », et aurait envoyé « false » pour un champ
                    auquel le vendeur n'a jamais touché. */}
                <option value="">— Non renseigné —</option>
                <option value="true">Oui</option>
                <option value="false">Non</option>
              </select>
            ) : (
              <Input
                id={champId}
                value={valeur}
                inputMode={def.type === "number" ? "decimal" : undefined}
                onChange={(e) => poser(def.key, e.target.value)}
                placeholder={def.type === "number" ? "Ex. 1.5" : undefined}
                aria-invalid={probleme !== null}
              />
            )}

            {probleme && <p className="text-xs text-destructive">{probleme}</p>}
          </div>
        );
      })}
    </div>
  );
}
